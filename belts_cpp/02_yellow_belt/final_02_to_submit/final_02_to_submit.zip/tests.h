#pragma once

#include <sstream>
#include <memory>  // std::shared_ptr

void TestParseCondition();
void TestParseEvent();
void TestAll();