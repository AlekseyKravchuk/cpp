#pragma once

void RunAllTests();
