#include <iostream>
#include <sstream>

#include "utilities.h"
#include "wrappers.h"

using namespace std;

string info_about_connected_client(sockaddr_storage& client_address) {
    char buf[INET6_ADDRSTRLEN];  // универсальный буфер, достаточный для хранения как адреса IPv4, так и адреса IPv6
    uint16_t port = 0;

    switch (client_address.ss_family) {
        case AF_INET: {  // IPv4
            auto* addr4 = (struct sockaddr_in *)&client_address;
            Inet_ntop(AF_INET, &addr4->sin_addr, buf, sizeof(buf));
            port = ntohs(addr4->sin_port);  // returns the value in host byte order
            break;
        }
        case AF_INET6: {  // IPv6
            auto* addr6 = (struct sockaddr_in6 *)&client_address;
            Inet_ntop(AF_INET6, &addr6->sin6_addr, buf, sizeof(buf));
            port = ntohs(addr6->sin6_port);  // returns the value in host byte order
            break;
        }
        default:         // Неизвестное семейство
            strcpy(buf, "Unknown family address");
    }

    ostringstream oss;
    oss << "Connected client: [IP = " << buf << "], "
        << "[PORT = " << port << "]" << endl;

    return oss.str();
}


void handle_client_connection(int connected_fd, const string& message) {
    size_t msg_len = message.size();
    size_t total_sent = 0;
    pid_t pid;

    size_t count = 0;
    constexpr size_t buffer_size = 1024;
    char buffer[buffer_size];


    while (total_sent < message.size()) {
        size_t len_to_send = std::min(buffer_size, msg_len - total_sent);
        memcpy(buffer, message.c_str() + total_sent, len_to_send);
        ssize_t num_bytes_sent = Send(connected_fd, buffer, len_to_send, 0);
        ++count;
        total_sent += static_cast<size_t>(num_bytes_sent);
    }

    cout << "Function send was called " << count << " times." << endl;
    cout << "Message sent to client.\n" << endl;
}

void handle_client_connection_concurrently(int connected_fd, const string& message) {
    size_t msg_len = message.size();
    size_t total_sent = 0;
    pid_t pid;

    size_t count = 0;
    constexpr size_t buffer_size = 1024;
    char buffer[buffer_size];

    if ( fork() == 0) {
        while (total_sent < message.size()) {
            size_t len_to_send = std::min(buffer_size, msg_len - total_sent);
            memcpy(buffer, message.c_str() + total_sent, len_to_send);
            ssize_t num_bytes_sent = Send(connected_fd, buffer, len_to_send, 0);
            ++count;
            total_sent += static_cast<size_t>(num_bytes_sent);
        }

//        cout << "Function send was called " << count << " times." << endl;
//        cout << "Message sent to client.\n" << endl;
    }

    cout << "Message sent to client.\n" << endl;

}