#pragma once

#include <string>

#include <sys/socket.h>
#include <netinet/in.h>

std::string info_about_connected_client(sockaddr_storage& client_address);

void handle_client_connection(int connected_fd, const std::string& message);

void handle_client_connection_concurrently(int connected_fd, const std::string& message);